import React from "react";
<<<<<<< Updated upstream
import {Link} from "react-router-dom";
=======
>>>>>>> Stashed changes

const Nav = () => (
  <nav className="navbar navbar-inverse navbar-top">
    <div className="container-fluid">
      <div className="navbar-header">
<<<<<<< Updated upstream
        <button type="button" 
                className="collapsed navbar-toggle"
                data-toggle="collapse"
                data-target=".navbar-ex1-collapse"
                >
          <span className="sr-only">Toggle navigation</span>
          <span className="icon-bar" /> 
          <span className="icon-bar" />
          <span className="icon-bar" />
        </button>
        <div className="collapse navbar-collapse navbar-ex1-collapse">
          <ul className="nav navbar-nav navbar-right">
            <li> 
              <h2>The Layout</h2>
            </li>
            <li> 
            <Link to="/">Sign Up</Link>
            </li>
            <li>
            <Link to="/books">Log in</Link>
            </li>
          </ul>
        </div>
=======
        <button type="button" className="collapsed navbar-toggle">
          <span className="sr-only">Toggle navigation</span>
          <span className="icon-bar" /> <span className="icon-bar" />
          <span className="icon-bar" />
        </button>
        <a href="/" className="navbar-brand">
          The Layover
        </a>
>>>>>>> Stashed changes
      </div>
    </div>
  </nav>
);

export default Nav;